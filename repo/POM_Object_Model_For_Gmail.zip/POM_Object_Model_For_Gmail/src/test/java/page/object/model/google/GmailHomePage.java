package page.object.model.google;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GmailHomePage {
	WebDriver driver;
	
	By signIn = By.xpath("");
	By createAnAccount = By.xpath("");
	
	public GmailHomePage(WebDriver driver) {
		this.driver = driver;		
	}
	
	public void clickSignIn() {
		driver.findElement(signIn).click();
	}
	
	public void clickCreateAnAccount() {
		driver.findElement(signIn).click();
	}	

}
